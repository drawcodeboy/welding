# Welding > 2025-03-19 12:48am
https://universe.roboflow.com/doby/welding-hnqmr

Provided by a Roboflow user
License: CC BY 4.0

